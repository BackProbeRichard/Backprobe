# Backprobe — Project Context

## What This Is

Backprobe is an abstraction layer between any consumer and a vehicle's OBD2 data. The consumer can be a GUI, terminal, MCP server, home automation system, cellular service, or anything else. The consumer never touches transport or protocol mechanics directly — that is Backprobe's job.

PyOBD and python-obd exist but are scan tools. Backprobe is infrastructure.

**The core abstraction is the product. The GUI is not. The MCP is not. They are test harnesses.**

---

## Current Scope

- Transport: J2534 only
- Protocol: OBD2 Modes 01–09 (SAE J1979 / ISO 15031-5)
- Runtime target: Windows 10/11, 32-bit Python (J2534 DLLs are 32-bit stdcall)
- Development: Linux (CachyOS), home desktop
- Do not add: ELM327, SocketCAN, DoIP, K-Line, UDS, KWP2000

Design for modularity and OS-agnosticism from the start, even if only Windows is supported now.
Design for transport modularity and agnosticism from the start, even if only j2534 is supported now

---

## Rules

- `OldVer/` is a reference archive — never modify it, never port code from it directly
- The repo root is the working tree; the importable package is `backprobe/` at the root (`python -m backprobe`)
- The GUI and MCP exist only to exercise the core API — do not let their needs drive core design unless the User overrides
- Every program generates a session log (see Logging Standard below)
- Discuss architecture before writing code

---

## Devices on Hand

- **Opus IVS Supergoose Plus** — J2534 passthru device (primary target, documentation requested from Opus IVS, this is our "validated device")
- **Autel Maxiflash VCMI** — J2534 device, on hand, supports multi-network polling; not yet in scope but confirms the multi-channel async case is real hardware, not hypothetical
- **Canable 2.0** — SocketCAN device, out of scope for now, future consideration, may be used a debugging tool if absolutel necessary, needs code to implement, last resort, try not to use it

---

## Two-Environment Workflow

- **Home desktop (Linux)** — all development happens here
- **Work laptop (Windows)** — test bench with live vehicle access; receives builds for hardware testing
- Code written here must run on Windows. Scripts or tools that run only on the dev machine must be clearly separated from anything destined for the test bench.

---

## Logging Standard

Every module ships with logging built in. The pattern from `OldVer/obd2_mcp/session_log.py` is the standard:

- One timestamped log file per session
- Thread-safe writes
- Source-tagged entries (which layer wrote the line)
- Raw CAN byte exchanges logged with hex and elapsed ms via `instrument_transport()`
- Full tracebacks on errors
- Crash handler covers both main thread and background threads
- System info written at session start

Fail loudly in logs, gracefully in behavior. Silent failure is not acceptable.

---

## Reference

- GitHub: https://github.com/BackProbeRichard/Backprobe
- OldVer contains v0.1.4 — read it to understand prior decisions, not as source to copy
