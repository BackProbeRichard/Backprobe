# Backprobe — Windows Bench Setup

*Instructions for the Claude agent setting up this project on the Windows test bench.*

---

## What this is

Backprobe is an OBD2 infrastructure daemon. On the bench it talks to the
**Opus IVS Supergoose Plus** (or any SAE J2534-compliant device) through its
32-bit Windows DLL. This file is a complete setup and validation guide.

---

## Prerequisites checklist

Work through these in order before running anything.

### 1 — 32-bit Python (mandatory, non-negotiable)

J2534 DLLs are 32-bit stdcall. The daemon **will not work** with 64-bit
Python. Verify before anything else:

```
python -c "import struct; print(struct.calcsize('P')*8)"
```

Must print `32`. If it prints `64`, install 32-bit Python from
python.org (Windows x86 installer) and use that interpreter for all
commands below.

### 2 — J2534 device driver

The Supergoose Plus driver must be installed and the device registered in
the Windows registry under `SOFTWARE\PassThruSupport.04.04`. The daemon
auto-discovers DLLs from the registry — you do not specify a path manually.

To verify the device is registered, run:

```
python -m backprobe --virtual --preset sedan_mil_on
```

This uses the virtual (fake) backend and does **not** need the device plugged
in. If the daemon starts, logs events, and exits cleanly, the Python
environment is correct. Move on.

### 3 — Get the code

Clone from GitHub (preferred) or copy the working tree from the dev machine:

```
git clone https://github.com/BackProbeRichard/Backprobe.git
cd Backprobe
```

No `pip install` is needed — Backprobe has zero third-party runtime
dependencies (pure Python stdlib + the OS-provided J2534 DLL).

---

## Smoke test (no vehicle needed)

Run the virtual backend to confirm the Python environment is wired up:

```
python -m backprobe --virtual --preset truck_healthy
```

Expected output (first few lines):

```
backend: virtual (preset=truck_healthy)
[HH:MM:SS] daemon_start  ...
[HH:MM:SS] device_opened  device=Virtual Pass-Thru ...
[state] SCANNING → HOLDING
[HH:MM:SS] voltage_detected ...
[state] HOLDING → INTERROGATING
[HH:MM:SS] probe_success  protocol=ISO15765  bitrate=500000  addressing=11-bit ...
[HH:MM:SS] connection_complete  ...
[state] INTERROGATING → ATTACHED
```

Stop with: close the window, or press `q` then Enter.
(Ctrl-C is intentionally disabled — it is a Windows copy shortcut.)

---

## Bench validation (vehicle required)

These are the Phase 1 "done" criteria. Work through them in order and note
pass/fail for each. All require the Supergoose plugged in and a 2008+ OBD2
vehicle connected.

Run the daemon in J2534 mode (default — no flags):

```
python -m backprobe
```

Logs are written to `./logs/` — one `session_*.log` (diagnostic) and one
`events_*.jsonl` (structured event stream) per run.

### Checklist

- [ ] **DLL discovery**: `enumerate()` finds the Supergoose in the registry.
      Confirm: `device_opened` event appears in the event log.

- [ ] **PassThruOpen / Connect**: daemon reaches HOLDING state and reads a
      voltage above 9000 mV with the vehicle connected and key on.

- [ ] **Probe confirms with real 0100**: `probe_success` event appears with
      the correct protocol (11-bit 500kbps for most vehicles).

- [ ] **VIN (0902) completes**: `vin_read` event appears. This proves the
      FC filter is working and multi-frame ISO-TP reassembly is correct.
      If VIN times out, the FC filter is broken — check the session log for
      `FILTER_WARN` entries.

- [ ] **Census finds all ECUs**: `ecu_census` lists at least Engine (0x7E8).
      If a Transmission ECU (0x7E9) is present, it should appear too.

- [ ] **Mode 06 (0601) completes per ECU**: `mode_06_results` events appear.

- [ ] **connection_complete fires**: confirms a full interrogation succeeded.

- [ ] **Release is absolute**: after every stop (close window, `q`, or device
      unplug), the OEM tool (or a second daemon run) opens the device
      immediately without a "device in use" error.

- [ ] **Device-unplug mid-run recovers**: physically unplug the Supergoose
      while the daemon is in ATTACHED state. The daemon should log
      `device_lost`, release cleanly, and return to SCANNING — not crash or
      exit. Replug to confirm it re-opens.

- [ ] **29-bit / 250 kbps vehicles** (if available): probe should advance
      past 11-bit profiles and succeed on the correct one.

### If multi-frame times out (VIN / Mode 06 hangs)

The most likely cause is the flow-control filter. Check the session log:

- `FILTER_WARN` — the DLL returned a warning on filter install. Note the
  J2534 error code and report it.
- If `RX_CLEAR_UNSUPPORTED` appears in the event log, the DLL does not
  support `CLEAR_RX_BUFFER`; the SID/PID match backstop is active. This is
  normal for some devices and does not block multi-frame.

If multi-frame still fails after confirming filters, test BS/STMIN: the
design doc (`Design Docs/PHASE_1_DOCS/PHASE_1_J2534_DESIGN.md`, Decision 6)
has explicit 04.04 values to try (`ISO15765_BS=0x1E, STMIN=0x1F`).

---

## Logs

| File | Purpose |
|------|---------|
| `logs/session_YYYYMMDD_HHMMSS.log` | Diagnostic text log — every event, raw CAN bytes, tracebacks |
| `logs/events_YYYYMMDD_HHMMSS.jsonl` | Structured JSONL event stream — the daemon's product output |

VINs in both logs have the serial digits (positions 12–17) replaced with a
stable keyed token. The full VIN is recoverable with the keyring at
`%USERPROFILE%\.config\backprobe\vin_keyring.tsv` if needed.

---

## Running the test suite (optional)

```
pip install pytest
python -m pytest
```

All 106 tests are pure-Python and run without hardware. They should all pass
before any bench session to confirm the environment is not corrupted.
